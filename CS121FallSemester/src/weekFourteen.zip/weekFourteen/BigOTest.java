package weekFourteen;

public class BigOTest {
    public static void main(String[] args) {
        BigO x = new BigO();
        x.printNSquaredTimes(4);
        x.printNTimes(3);
    }
}
